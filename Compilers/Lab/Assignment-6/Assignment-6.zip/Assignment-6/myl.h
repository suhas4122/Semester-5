/* Suhas Jain | 19CS30048    */
/* Monal Prasad  | 19CS30030    */
#ifndef _MYL_H
#define _MYL_H
#define ERR 1
#define OK 0
int printStr(char *);
int printInt(int);
int readInt(int *eP); 	// *n is for error, if the input is not an integer
#endif